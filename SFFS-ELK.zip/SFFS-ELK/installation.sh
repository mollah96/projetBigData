wget https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-7.5.2-linux-x86_64.tar.gz
wget https://artifacts.elastic.co/downloads/kibana/kibana-7.5.2-linux-x86_64.tar.gz
wget https://artifacts.elastic.co/downloads/logstash/logstash-7.5.2.tar.gz
tar -xvzf elasticsearch-7.5.2-linux-x86_64.tar.gz
tar -xvzf kibana-7.5.2-linux-x86_64.tar.gz
tar -xvzf logstash-7.5.2.tar.gz
rm -f elasticsearch-7.5.2-linux-x86_64.tar.gz
rm -f kibana-7.5.2-linux-x86_64.tar.gz
rm -f logstash-7.5.2.tar.gz
mv ./elasticsearch-7.5.2 elasticsearch
mv ./kibana-7.5.2-linux-x86_64 kibana
mv ./logstash-7.5.2 logstash
