mkdir data
cd data
wget https://raw.githubusercontent.com/bvaughn/infinite-list-reflow-examples/master/books.json
cd ..

logstash/bin/logstash -f logstash-ex1.conf
