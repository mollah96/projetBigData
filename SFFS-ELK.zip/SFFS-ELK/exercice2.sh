cd data
wget https://data.cityofchicago.org/api/views/vc9r-bqvy/rows.csv?accessType=DOWNLOAD -O chicago.csv
cd ..

logstash/bin/logstash -f logstash-ex2.conf
